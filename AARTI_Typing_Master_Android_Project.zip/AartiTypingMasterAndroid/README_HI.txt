AARTI TYPING MASTER - Android project

यह Android Studio में खोलने योग्य शुरुआती प्रोजेक्ट है।
इसमें मौजूदा typing tutor को Android WebView ऐप में रखा गया है।

बनाने के चरण:
1. Android Studio में इस फ़ोल्डर को Open करें।
2. Gradle sync पूरा होने दें (Android SDK 35 और JDK 17 आवश्यक हो सकते हैं)।
3. Run दबाकर मोबाइल/एमुलेटर पर जाँचें।
4. रिलीज़ के लिए Build > Generate Signed Bundle / APK चुनें।
5. Play Store पर प्रकाशित करने के लिए signed Android App Bundle (AAB),
   Play Console developer account, store listing, privacy policy और
   Google Play की मौजूदा नीतियों का पालन आवश्यक है।

महत्वपूर्ण:
- यह source project है, तैयार APK/AAB नहीं।
- इसे Play Store पर प्रकाशित नहीं किया गया है।
- रिजल्ट अभी इसी ऐप/डिवाइस के स्थानीय browser storage में सेव होते हैं;
  अलग-अलग डिवाइस में अपने-आप sync नहीं होंगे।
- हिंदी टाइपिंग के लिए डिवाइस में हिंदी Unicode keyboard/input उपलब्ध होना चाहिए।
- ऐप प्रकाशित करने से पहले वास्तविक डिवाइस पर पूरी जाँच, ऐप आइकन,
  स्क्रीनशॉट, privacy policy और आवश्यक Play Console घोषणाएँ तैयार करें।
